package com.company.exp;public class AppBadRequestExceptionImpl extends AppBadRequestException {
    public AppBadRequestExceptionImpl(String message) {
        super(message);
    }
}
