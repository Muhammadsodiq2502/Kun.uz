package com.company.enums;

public enum ArticleStatus {
    CREATED, PUBLISHED, BLOCKED
}
