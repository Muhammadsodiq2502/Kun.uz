package com.company.enums;

public enum ProfileRole {
    USER, ADMIN, MODERATOR, PUBLISHER
}
