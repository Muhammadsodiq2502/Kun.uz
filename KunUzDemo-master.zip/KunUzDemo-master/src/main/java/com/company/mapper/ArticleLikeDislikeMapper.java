package com.company.mapper;

public interface ArticleLikeDislikeMapper {
    Integer getLike_count();

    Integer getDislike_count();
}
